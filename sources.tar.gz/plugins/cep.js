(function(factory){
	function cepQueryAddress(a, f){

		if(typeof f !== "function"){
			f = (r) => (factory.cep.result = r||false);
		}

		this.result = {};

		if(typeof a == "string"){
			a = a.split(/[^0-9]/).join('');

			if(a.length != 8){
				return f(false);
			}
		}

		return factory.request("https://viacep.com.br/ws/" + a + "/json/", f);
	}

	factory.cep = (a = -1, f = -1) => new cepQueryAddress(a, f);

	factory.cep.result = false;
})(LWDK);
